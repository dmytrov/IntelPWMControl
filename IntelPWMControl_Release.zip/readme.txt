
IntelPWMControl enables adjustment of the default LCD backlight PWM frequency on some systems with recent Intel integrated graphics. To change the backlight PWM frequency, run one of the following on system startup:

IntelPWMControl_x86 <PWM Frequency>
IntelPWMControl_x64 <PWM Frequency>

<PWM Frequency> defaults to 600 Hz if not specifed

Note: x86 version won't work on 64-bit systems, so you are required to use IntelPWMControl_x64 there

How it works:

IntelPWMControl runs in the background and queries the graphics driver for the current PWM frequency once per second, adjusting it to specified value if necessary (adjusting LCD brightness may revert the PWM frequency to the default value, so IntelPWMControl is required to be running all the time).
Bug: your screen may flicker when the PWM frequency changes.

